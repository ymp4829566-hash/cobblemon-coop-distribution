# Bobby: unofficial NeoForge port

Original author: **johni0702**. Original source: https://github.com/Johni0702/bobby

Based on `v5.2.4.1+mc1.21`, commit `750b689633ab08f48c16fdf9ec923d9fa3763868`. Port version: `5.2.4.1-neoforge.1`. Development target: Minecraft1.21.1 / NeoForge21.1.256 / Java21 / Sodium0.8.13. This is an independently modified community port, **not an official release** and not maintained or endorsed by the original author. Retain the original attribution and both original license documents.

## Modifications

- Replaced Fabric initialization, config-directory lookup and client command registration with native NeoForge APIs; Minecraft state is accessed after client setup on the client thread.
- Migrated Yarn names to Mojang mappings and ported chunk/lighting/renderer hooks for the target version. Persistent region cache and server-supplied cache path containment remain part of the original design.
- Replaced optional Fabric Mod Menu/Cloth Config integration with a native eight-setting configuration screen and NeoForge mod-list extension. HOCON/config watcher remains; asynchronous write failure is reported and client-side config effects are queued on the client thread.
- Added the Sodium0.8.13 integration in place of obsolete0.5/0.6 compatibility code. The build resolves the official Sodium bundle for compile-time API extraction, not inclusion/redistribution inside Bobby.
- Raised the supported client maximum to64 (bounded3–64). The user's selected Minecraft render distance is **not forced to64**. The distinct integrated-server overwrite remains0–32, and dedicated-server simulation distance is unchanged.
- Replaced Fabric FREX entrypoint discovery with public `FlawlessFrames.getProvider()` and a NeoForge `FlawlessFrames.ProviderEvent`. Native consumers must explicitly use that API/event; old Fabric entrypoint consumers are not automatically bridged.
- Added native/headless regression tests, English native-screen wording and Korean configuration-screen translations. Cache cleanup is bounded to `.bobby` and does not recursively remove parent game folders or follow cache-directory symlinks outside that root.

## Scope

Client-only. Do not install it on a dedicated server. It shows cached terrain previously received from a server, not unknown terrain or live distant machine/entity activity. Cached data can be outdated; live/cache lighting or block seams are possible.64 chunks can use approximately four times the horizontal chunk area of32 and is not a guaranteed FPS improvement. This notice does not claim actual GPU/gameplay tests; see release-specific QA evidence for checks actually performed.

## License and corresponding source

The pinned original source declares **LGPL-3.0-or-later**. `LICENSE.md` and `LICENSE.LESSER.md` are unchanged and included in the distributable. Preserve copyright and license notices, identify modifications, and supply the exact corresponding complete source/build materials when distributing the modified binary. Recipients must be able to inspect, modify and rebuild that release under the applicable license terms. The matching source archive should include Java/resources, Gradle scripts/properties/wrapper, README, this notice and license files; a sources-only JAR must not replace necessary build instructions/materials. Bundled dependencies keep their own original license notices. This brief notice does not replace the license text.

Build instructions and configuration meanings are in `README.md`: JDK21 plus `gradlew.bat clean build`, no external source checkout paths required. The build downloads official dependencies on first use. No Fabric API, Mod Menu or Cloth Config is required by this port.
