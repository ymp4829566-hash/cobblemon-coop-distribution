# Bobby — unofficial NeoForge 1.21.1 port

A separate, client-only port of [johni0702's Bobby](https://github.com/Johni0702/bobby), based on `v5.2.4.1+mc1.21`, commit `750b689633ab08f48c16fdf9ec923d9fa3763868`. It is not an official Bobby release and is not endorsed by the original author. The port keeps mod ID `bobby` and the persistent client region cache, while replacing Fabric integration with native NeoForge integration.

## Target and installation

Target environment: Minecraft **1.21.1**, NeoForge **21.1.256**, Java **21**, and the official NeoForge **Sodium 0.8.13** release. Metadata permits a bounded range of newer compatible loader/Sodium versions; the development target is the exact combination above, not every version in those ranges.

Put the distributable `bobby-neoforge-5.2.4.1-neoforge.1.jar` in the client's `mods` folder alongside the official Sodium NeoForge JAR. Remove an old Bobby JAR from that same profile instead of loading two `bobby` mods. Do not install the Fabric JAR or Fabric API/Mod Menu/Cloth Config to satisfy this port. Configurate and its small libraries are included as JarJar dependencies. Never install a `-sources.jar`, QA JAR, or extracted Sodium implementation as a game mod.

**No dedicated-server installation is needed.** This is not a server chunk loader and does not change server view distance, simulation distance, mob spawning, machine ticking, or network delivery. In multiplayer it renders cached terrain that the server previously supplied. Areas that have never been supplied cannot be reconstructed from nothing. Cached blocks can be stale while outside the live server area; distant entities and ongoing machine states do not become live merely because terrain is visible. Lighting or block differences may appear at live/cache boundaries.

The separate NeoForge CurseForge profile is `코블몬 협동 NeoForge`. This source tree does not itself publish a patcher manifest or operate the server. The existing Fabric profile and cache should be backed up and kept separately. The basic cache format is retained, but an existing cache's Minecraft version, server identity, dimension and dynamic-world metadata must match; do not treat arbitrary cache copying as a verified migration.

## 64 chunks is selectable, not forced

The fresh configuration allows a render-distance **maximum of 64**. It does **not** overwrite Minecraft's currently selected render distance or force the slider to 64. An existing `bobby.conf` value remains user-owned and is constrained to a valid 3–64 limit. If you deliberately lower the configured maximum below your selected distance, the selected distance is reduced to that maximum.

Use Minecraft/Sodium video settings to choose your actual distance. Start with 24 or 32 if necessary, then try 48 or 64. A 64-radius area contains approximately four times as many horizontal chunks as 32; memory, GPU geometry, cache I/O and rebuild cost still apply. Entity Culling/ModernFix do not make that cost disappear. This port promises a supported setting/code path, not a minimum FPS or a performance improvement on every computer.

## Configuration and commands

Open **Mods → Bobby - NeoForge Community Port → Config**. The native screen has two pages, preserves draft values when changing pages/resizing, and provides Save, Cancel and Reset. Reset changes the draft only; Save is required to persist it. Save waits for the asynchronous configuration write and reports failures. Esc cancels unsaved changes; controls/closing are temporarily disabled during a pending write.

The same settings are stored in `config/bobby.conf` in HOCON format and watched for external edits. Make a backup before manual edits. Invalid loading is logged; do not overwrite a damaged configuration just to clear a warning.

| Setting | Meaning |
| --- | --- |
| Enabled | Enable Bobby in multiplayer. |
| Dynamic World Management | Detect/keep distinct server worlds with identical names; merging requires enough matching chunk data. Use `/bobby upgrade` when enabling it with an old cache. |
| Disable Block Entities | Omit block entities from cached terrain; enabled by default to reduce client work. |
| Taint Fake Chunks | Darken cached chunks to distinguish them from live chunks. |
| Chunk Unload Delay | Seconds to retain chunks after leaving view range; does not span dimensions. |
| Cleanup Unused Regions | Days before cleanup; `-1` disables automatic cleanup, while `0` removes caches very aggressively after disconnects. Keep `-1` when persistent revisiting is your goal. |
| Max Render Distance | Maximum selectable client render distance, 3–64. |
| Singleplayer Server View Distance | Integrated-server overwrite, 0–32; 0 disables it and Bobby's singleplayer mode. Rejoin the world when enabling/disabling. This is distinct from the client's cached 64-chunk limit. |

Original client commands are retained: `/bobby worlds`, `/bobby worlds full`, `/bobby worlds create`, `/bobby worlds merge <source> <target>`, and `/bobby upgrade`. The IDs used by merge are displayed by the worlds command. Back up the cache before upgrades/merging; these commands do not edit the dedicated server's world. The client cache is under `.bobby` in the game directory.

## Build the matching source

On Windows, install JDK21 and use the included Gradle8.14.3 wrapper:

```powershell
$env:JAVA_HOME = 'C:\Program Files\Java\jdk-21.0.10'
.\gradlew.bat clean build
```

The first build requires internet access to resolve NeoForge/Minecraft, ModDevGradle2.0.148, Configurate4.1.2 and the exact official Sodium bundle. The build fetches Sodium from the official Modrinth Maven endpoint, checks the pinned bundle SHA-256, and extracts its nested implementation for **compile-time use only**. Sodium is neither copied into Bobby nor republished as part of this mod.

The distributable and source JARs are generated under `build/libs`. `build` includes `verifyBobbyUnit`: headless JUnit against patched Minecraft/NeoForge classes. For that suite alone run `./gradlew.bat verifyBobbyUnit`. The usual Gradle `test` task is disabled in favor of this explicit console-runner task because of Gradle worker classpath problems in the Windows Unicode workspace; running `test` alone is not verification. No game client is launched by those tests.

For redistribution, provide the **exact corresponding complete source/build archive** alongside the binary, including Gradle files/wrapper, resources, this README, port notice, and both license documents. A sources-only JAR is not a substitute for the build/configuration material needed to modify and rebuild the matching release. Check the final release's actual test reports and artifact hashes; this README is not a test result.

## Integration and verification limits

Fabric's `frex_flawless_frames` entrypoint discovery is replaced by `de.johni0702.minecraft.bobby.util.FlawlessFrames.getProvider()` and a `FlawlessFrames.ProviderEvent` on the NeoForge event bus during client setup. A capturing mod must use the native API/event; an unported Fabric consumer is not automatically discovered. Each consumer receives an independent token, so one consumer cannot cancel another's request for complete cached frames.

The port also uses Mojang mappings, native client commands, a native configuration screen and Sodium0.8.13 hooks. Old Sodium0.5/0.6 integration is not loaded. Server-supplied cache path containment is preserved; automatic cleanup must remain inside the local `.bobby` cache and does not climb into the game directory.

Headless compilation/unit/static checks do not prove actual GPU rendering, shaders, reconnect/dimension presentation, live/cache seams, sustained64-chunk memory use or two-player gameplay. **No actual GPU game tests are claimed here.** Game runtime acceptance and hardware-specific performance measurements remain separate from these build instructions.

## License and attribution

Original author: **johni0702**. Original project: [Bobby source](https://github.com/Johni0702/bobby), [Modrinth](https://modrinth.com/mod/bobby). The pinned original source's metadata specifies **LGPL-3.0-or-later**; retain [LICENSE.md](LICENSE.md), [LICENSE.LESSER.md](LICENSE.LESSER.md), copyright notices and [PORTING-NOTICE.md](PORTING-NOTICE.md). Dependencies retain their own notices/licenses inside their original bundled JARs. Follow the license's source/rebuild and recipient-rights requirements when distributing this modified binary; do not label it an official upstream release.
