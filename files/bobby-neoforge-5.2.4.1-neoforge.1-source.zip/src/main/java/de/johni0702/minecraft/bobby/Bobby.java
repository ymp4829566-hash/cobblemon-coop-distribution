package de.johni0702.minecraft.bobby;

import de.johni0702.minecraft.bobby.ext.ClientChunkManagerExt;
import de.johni0702.minecraft.bobby.mixin.SimpleOptionAccessor;
import de.johni0702.minecraft.bobby.mixin.ValidatingIntSliderCallbacksAccessor;
import de.johni0702.minecraft.bobby.util.FlawlessFrames;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.common.NeoForge;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.configurate.CommentedConfigurationNode;
import org.spongepowered.configurate.hocon.HoconConfigurationLoader;
import org.spongepowered.configurate.reference.ConfigurationReference;
import org.spongepowered.configurate.reference.ValueReference;
import org.spongepowered.configurate.reference.WatchServiceListener;
import org.spongepowered.configurate.reactive.Subscriber;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.LinkOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.concurrent.CompletableFuture;

@Mod(value = Bobby.MOD_ID, dist = Dist.CLIENT)
public class Bobby {
    private static final Logger LOGGER = LogManager.getLogger();

    public static final String MOD_ID = "bobby";
    private static Bobby instance;
    public static Bobby getInstance() {
        return instance;
    }

    private Minecraft client;

    private volatile ValueReference<BobbyConfig, CommentedConfigurationNode> configReference;

    public Bobby(IEventBus modBus, ModContainer container) {
        instance = this;
        modBus.addListener(this::onClientSetup);
        NeoForge.EVENT_BUS.addListener(BobbyClientCommands::register);
        container.registerExtensionPoint(IConfigScreenFactory.class,
                (IConfigScreenFactory) (mod, parent) -> createConfigScreen(parent));
    }

    private void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(this::onInitializeClient);
    }

    private void onInitializeClient() {
        client = Minecraft.getInstance();
        try {
            Path configPath = FMLPaths.CONFIGDIR.get().resolve(MOD_ID + ".conf");
            @SuppressWarnings("resource") // we'll keep this around for the entire lifetime of our mod
            ConfigurationReference<CommentedConfigurationNode> rootRef = createWatchServiceListener()
                    .listenToConfiguration(path -> HoconConfigurationLoader.builder().path(path).build(), configPath);
            rootRef.errors().subscribe(failure -> LOGGER.error("Bobby configuration " + failure.getKey() + " failed", failure.getValue()));
            configReference = rootRef.referenceTo(BobbyConfig.class);
            rootRef.saveAsync().subscribe(new Subscriber<CommentedConfigurationNode>() {
                @Override
                public void submit(CommentedConfigurationNode value) {}

                @Override
                public void onError(Throwable error) {
                    LOGGER.error("Failed to save initial Bobby configuration", error);
                }
            });
        } catch (IOException e) {
            LOGGER.error("Failed to initialize Bobby configuration; using defaults", e);
        }

        FlawlessFrames.onClientInitialization();

        TaintChunksConfigHandler taintHandler = new TaintChunksConfigHandler();
        MaxRenderDistanceConfigHandler distanceHandler = new MaxRenderDistanceConfigHandler();
        if (configReference != null) {
            configReference.subscribe(taintHandler::update);
            configReference.subscribe(distanceHandler::update);
        }

        Util.ioPool().submit(this::cleanupOldWorlds);
    }

    public BobbyConfig getConfig() {
        ValueReference<BobbyConfig, CommentedConfigurationNode> reference = configReference;
        BobbyConfig config = reference == null ? null : reference.get();
        return config != null ? config : BobbyConfig.DEFAULT;
    }

    public boolean isEnabled() {
        BobbyConfig config = getConfig();
        return config.isEnabled()
                // For singleplayer, disable ourselves unless the view-distance overwrite is active.
                && (Minecraft.getInstance().getSingleplayerServer() == null || config.getViewDistanceOverwrite() != 0);
    }

    public Screen createConfigScreen(Screen parent) {
        return BobbyConfigScreenFactory.createConfigScreen(parent, getConfig(), config -> {
            ValueReference<BobbyConfig, CommentedConfigurationNode> reference = configReference;
            if (reference == null) {
                return CompletableFuture.failedFuture(new IllegalStateException(Component.translatable("bobby.config.load_error").getString()));
            }
            CompletableFuture<Void> saved = new CompletableFuture<>();
            reference.setAndSaveAsync(config).subscribe(new Subscriber<Boolean>() {
                @Override
                public void submit(Boolean success) {
                    if (Boolean.TRUE.equals(success)) {
                        saved.complete(null);
                    } else {
                        saved.completeExceptionally(new IOException("Bobby configuration could not be serialized"));
                    }
                }

                @Override
                public void onError(Throwable error) {
                    LOGGER.error("Failed to save Bobby settings", error);
                    saved.completeExceptionally(error);
                }
            });
            return saved;
        });
    }

    private void cleanupOldWorlds() {
        int deleteUnusedRegionsAfterDays = Bobby.getInstance().getConfig().getDeleteUnusedRegionsAfterDays();
        if (deleteUnusedRegionsAfterDays < 0) {
            return;
        }

        Path basePath = client.gameDirectory.toPath().resolve(".bobby").toAbsolutePath().normalize();
        if (!Files.isDirectory(basePath, LinkOption.NOFOLLOW_LINKS)) {
            return;
        }

        List<Path> toBeDeleted;
        try (Stream<Path> stream = Files.walk(basePath, 4)) {
            toBeDeleted = stream
                    .filter(it -> basePath.relativize(it).getNameCount() == 4)
                    .filter(it -> Files.isDirectory(it, LinkOption.NOFOLLOW_LINKS))
                    .flatMap(directory -> {
                        try {
                            if (Files.exists(Worlds.metaFile(directory))) {
                                List<Path> worlds;
                                try (Stream<Path> fStream = Files.list(directory)) {
                                    worlds = fStream.filter(path -> Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)).collect(Collectors.toList());
                                }
                                boolean stillHasWorlds = false;
                                List<Path> toDelete = new ArrayList<>();
                                for (Path world : worlds) {
                                    if (LastAccessFile.isEverythingOlderThan(world, deleteUnusedRegionsAfterDays)) {
                                        try (Stream<Path> fStream = Files.list(world)) {
                                            fStream.forEach(toDelete::add);
                                        }
                                    } else {
                                        stillHasWorlds = true;
                                    }
                                }
                                if (!stillHasWorlds && LastAccessFile.isEverythingOlderThan(directory, deleteUnusedRegionsAfterDays)) {
                                    try (Stream<Path> fStream = Files.list(directory)) {
                                        fStream.forEach(toDelete::add);
                                    }
                                }
                                return toDelete.stream();
                            } else {
                                if (LastAccessFile.isEverythingOlderThan(directory, deleteUnusedRegionsAfterDays)) {
                                    try (Stream<Path> fStream = Files.list(directory)) {
                                        return fStream.toList().stream();
                                    }
                                }
                            }
                        } catch (IOException e) {
                            LOGGER.error("Failed to read last used file in " + directory + ":", e);
                        }
                        return Stream.empty();
                    })
                    .collect(Collectors.toList());
        } catch (IOException e) {
            LOGGER.error("Failed to index bobby cache for cleanup:", e);
            return;
        }

        for (Path path : toBeDeleted) {
            if (!Files.exists(path)) continue;
            try {
                if (!path.toRealPath().startsWith(basePath.toRealPath())) {
                    LOGGER.warn("Skipping cache cleanup path outside Bobby cache: {}", path);
                    continue;
                }
                Files.delete(path);
                deleteParentsIfEmpty(path, basePath);
            } catch (IOException e) {
                LOGGER.error("Failed to delete " + path + ":", e);
            }
        }
    }

    private static void deleteParentsIfEmpty(Path path, Path basePath) throws IOException {
        Path parent = path.getParent();
        if (parent == null || parent.equals(basePath) || !parent.startsWith(basePath)
                || !Files.isDirectory(parent, LinkOption.NOFOLLOW_LINKS)
                || !parent.toRealPath().startsWith(basePath.toRealPath())) {
            return;
        }
        try (Stream<Path> stream = Files.list(parent)) {
            if (stream.findAny().isPresent()) {
                return;
            }
        }
        Files.delete(parent);
        deleteParentsIfEmpty(parent, basePath);
    }

    private static WatchServiceListener createWatchServiceListener() throws IOException {
        WatchServiceListener listener = WatchServiceListener.create();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                listener.close();
            } catch (IOException e) {
                LOGGER.catching(e);
            }
        }, "Configurate shutdown thread (Bobby)"));

        return listener;
    }

    private class TaintChunksConfigHandler {
        private boolean wasEnabled = getConfig().isTaintFakeChunks();

        public void update(BobbyConfig config) {
            if (config == null) {
                return;
            }
            client.submit(() -> setEnabled(config.isTaintFakeChunks()));
        }

        private void setEnabled(boolean enabled) {
            if (wasEnabled == enabled) {
                return;
            }
            wasEnabled = enabled;

            ClientLevel world = client.level;
            if (world == null) {
                return;
            }

            FakeChunkManager bobbyChunkManager = ((ClientChunkManagerExt) world.getChunkSource()).bobby_getFakeChunkManager();
            if (bobbyChunkManager == null) {
                return;
            }

            for (LevelChunk fakeChunk : bobbyChunkManager.getFakeChunks()) {
                ((FakeChunk) fakeChunk).setTainted(enabled);
            }
        }
    }

    private class MaxRenderDistanceConfigHandler {
        private int oldMaxRenderDistance = 0;

        {
            update(getConfig(), true);
        }

        public void update(BobbyConfig config) {
            update(config, false);
        }

        public void update(BobbyConfig config, boolean increaseOnly) {
            if (config == null) {
                return;
            }
            client.submit(() -> setMaxRenderDistance(config.getMaxRenderDistance(), increaseOnly));
        }

        @SuppressWarnings({"ConstantConditions", "unchecked"})
        private void setMaxRenderDistance(int newMaxRenderDistance, boolean increaseOnly) {
            if (oldMaxRenderDistance == newMaxRenderDistance) {
                return;
            }
            oldMaxRenderDistance = newMaxRenderDistance;

            OptionInstance<Integer> viewDistance = client.options.renderDistance();
            if (viewDistance.values() instanceof OptionInstance.IntRange callbacks) {
                ValidatingIntSliderCallbacksAccessor callbacksAcc = (ValidatingIntSliderCallbacksAccessor)(Object) callbacks;
                if (increaseOnly) {
                    callbacksAcc.setMaxInclusive(Math.max(callbacks.maxInclusive(), newMaxRenderDistance));
                } else {
                    callbacksAcc.setMaxInclusive(newMaxRenderDistance);
                }
                SimpleOptionAccessor<Integer> optionAccessor = (SimpleOptionAccessor<Integer>)(Object) viewDistance;
                optionAccessor.setCodec(callbacks.codec());
                if (!increaseOnly && viewDistance.get() > newMaxRenderDistance) {
                    viewDistance.set(newMaxRenderDistance);
                }
            }
        }
    }
}
