package de.johni0702.minecraft.bobby;

import de.johni0702.minecraft.bobby.commands.CreateWorldCommand;
import de.johni0702.minecraft.bobby.commands.MergeWorldsCommand;
import de.johni0702.minecraft.bobby.commands.UpgradeCommand;
import de.johni0702.minecraft.bobby.commands.WorldsCommand;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;

import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

/** Native client-only command registration; no commands are sent to the server. */
public final class BobbyClientCommands {
    private BobbyClientCommands() {}

    public static void register(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(literal("bobby")
                .then(literal("worlds").executes(new WorldsCommand(false))
                        .then(literal("full").executes(new WorldsCommand(true)))
                        .then(literal("merge")
                                .then(argument("source", integer())
                                        .then(argument("target", integer())
                                                .executes(new MergeWorldsCommand()))))
                        .then(literal("create").executes(new CreateWorldCommand())))
                .then(literal("upgrade").executes(new UpgradeCommand())));
    }

    /** World/cache commands may finish asynchronously; marshal chat updates to the client thread. */
    public static void sendFeedback(CommandSourceStack source, Component message) {
        Minecraft.getInstance().execute(() -> source.sendSuccess(() -> message, false));
    }

    public static void sendError(CommandSourceStack source, Component message) {
        Minecraft.getInstance().execute(() -> source.sendFailure(message));
    }
}
