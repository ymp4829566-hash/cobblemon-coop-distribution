package de.johni0702.minecraft.bobby;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.function.Function;

/** Native NeoForge config screen. All eight upstream settings are available without Cloth Config or Mod Menu. */
public final class BobbyConfigScreenFactory {
    private BobbyConfigScreenFactory() {}

    public static Screen createConfigScreen(Screen parent, BobbyConfig config, Function<BobbyConfig, CompletableFuture<Void>> update) {
        return new SettingsScreen(parent, config, update);
    }

    private static final class SettingsScreen extends Screen {
        private static final String[] TOGGLE_KEYS = {
                "enabled", "dynamic_multi_world", "no_block_entities", "taint_fake_chunks"
        };
        private static final String[] NUMBER_KEYS = {
                "unload_delay", "delete_unused_regions_after_days", "max_render_distance", "view_distance_overwrite"
        };

        private final Screen parent;
        private final Function<BobbyConfig, CompletableFuture<Void>> update;
        private final boolean[] toggles = new boolean[4];
        private final String[] numbers = new String[4];
        private int page;
        private Component error;
        private int left;
        private int bodyWidth;
        private int rowHeight;
        private boolean saving;
        private Button saveButton;

        private SettingsScreen(Screen parent, BobbyConfig config, Function<BobbyConfig, CompletableFuture<Void>> update) {
            super(Component.translatable("title.bobby.config"));
            this.parent = parent;
            this.update = update;
            loadDraft(config);
        }

        private void loadDraft(BobbyConfig config) {
            toggles[0] = config.isEnabled();
            toggles[1] = config.isDynamicMultiWorld();
            toggles[2] = config.isNoBlockEntities();
            toggles[3] = config.isTaintFakeChunks();
            numbers[0] = Integer.toString(config.getUnloadDelaySecs());
            numbers[1] = Integer.toString(config.getDeleteUnusedRegionsAfterDays());
            numbers[2] = Integer.toString(config.getMaxRenderDistance());
            numbers[3] = Integer.toString(config.getViewDistanceOverwrite());
        }

        @Override
        protected void init() {
            bodyWidth = Math.max(120, Math.min(420, width - 28));
            left = (width - bodyWidth) / 2;
            rowHeight = Math.max(23, Math.min(34, (height - 100) / 4));
            int fieldWidth = Math.min(80, bodyWidth / 3);
            for (int index = 0; index < 4; index++) {
                final int setting = index;
                int y = 42 + index * rowHeight;
                if (page == 0) {
                    Button toggle = Button.builder(toggleValue(index), button -> {
                        toggles[setting] = !toggles[setting];
                        button.setMessage(toggleValue(setting));
                    }).bounds(left + bodyWidth - fieldWidth, y, fieldWidth, 20).build();
                    if (index != 0) {
                        toggle.setTooltip(Tooltip.create(Component.translatable("tooltip.option.bobby." + TOGGLE_KEYS[index])));
                    }
                    addRenderableWidget(toggle);
                } else {
                    EditBox field = new EditBox(font, left + bodyWidth - fieldWidth, y, fieldWidth, 20,
                            Component.translatable("option.bobby." + NUMBER_KEYS[index]));
                    field.setMaxLength(11);
                    field.setFilter(value -> value.matches("-?\\d*"));
                    field.setValue(numbers[index]);
                    field.setResponder(value -> {
                        numbers[setting] = value;
                        error = null;
                    });
                    field.setTooltip(Tooltip.create(Component.translatable("tooltip.option.bobby." + NUMBER_KEYS[index])));
                    addRenderableWidget(field);
                }
            }

            int gap = 4;
            int buttonWidth = (bodyWidth - 3 * gap) / 4;
            int bottom = height - 29;
            addRenderableWidget(Button.builder(Component.translatable("bobby.config.page", page + 1, 2), button -> {
                page = 1 - page;
                rebuildWidgets();
            }).bounds(left, bottom, buttonWidth, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("controls.reset"), button -> {
                loadDraft(BobbyConfig.DEFAULT);
                error = null;
                rebuildWidgets();
            }).bounds(left + (buttonWidth + gap), bottom, buttonWidth, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("gui.cancel"), button -> onClose())
                    .bounds(left + 2 * (buttonWidth + gap), bottom, buttonWidth, 20).build());
            saveButton = addRenderableWidget(Button.builder(Component.translatable(saving ? "bobby.config.saving" : "gui.done"), button -> save())
                    .bounds(left + 3 * (buttonWidth + gap), bottom, buttonWidth, 20).build());
            setInputsActive(!saving);
        }

        private Component toggleValue(int index) {
            return Component.translatable(toggles[index] ? "options.on" : "options.off");
        }

        private int number(int index, int minimum, int maximum) {
            try {
                int result = Integer.parseInt(numbers[index]);
                if (result >= minimum && result <= maximum) {
                    return result;
                }
            } catch (NumberFormatException ignored) {
                // An incomplete edit (e.g. just a minus sign) must not be persisted.
            }
            throw new IllegalArgumentException(Component.translatable("bobby.config.range_error",
                    Component.translatable("option.bobby." + NUMBER_KEYS[index]), minimum, maximum).getString());
        }

        private void save() {
            if (saving) {
                return;
            }
            try {
                BobbyConfig next = new BobbyConfig(toggles[0], toggles[1], toggles[2], toggles[3],
                        number(0, 0, Integer.MAX_VALUE), number(1, -1, Integer.MAX_VALUE),
                        number(2, 3, 64), number(3, 0, 32));
                saving = true;
                setInputsActive(false);
                saveButton.setMessage(Component.translatable("bobby.config.saving"));
                update.apply(next).whenComplete((ignored, failure) -> minecraft.execute(() -> {
                    saving = false;
                    if (minecraft.screen != this) {
                        return;
                    }
                    if (failure == null) {
                        onClose();
                    } else {
                        showError(failure);
                        setInputsActive(true);
                        saveButton.setMessage(Component.translatable("gui.done"));
                    }
                }));
            } catch (RuntimeException exception) {
                saving = false;
                showError(exception);
                setInputsActive(true);
                saveButton.setMessage(Component.translatable("gui.done"));
                if (page != 1) {
                    page = 1;
                    rebuildWidgets();
                }
            }
        }

        private void showError(Throwable failure) {
            while (failure instanceof CompletionException && failure.getCause() != null) {
                failure = failure.getCause();
            }
            error = Component.translatable("bobby.config.save_error",
                    failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage());
        }

        private void setInputsActive(boolean active) {
            children().forEach(child -> {
                if (child instanceof AbstractWidget widget) {
                    widget.active = active;
                }
            });
        }

        @Override
        public boolean shouldCloseOnEsc() {
            return !saving;
        }

        @Override
        public void onClose() {
            if (!saving) {
                minecraft.setScreen(parent);
            }
        }

        @Override
        public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            renderBackground(graphics, mouseX, mouseY, partialTick);
            super.render(graphics, mouseX, mouseY, partialTick);
            graphics.drawCenteredString(font, title, width / 2, 13, 0xFFFFFF);
            String[] keys = page == 0 ? TOGGLE_KEYS : NUMBER_KEYS;
            int labelWidth = bodyWidth - Math.min(80, bodyWidth / 3) - 10;
            for (int index = 0; index < 4; index++) {
                graphics.drawWordWrap(font, Component.translatable("option.bobby." + keys[index]),
                        left, 44 + index * rowHeight, labelWidth, 0xFFFFFF);
            }
            if (error != null) {
                graphics.drawWordWrap(font, error, left, height - 51, bodyWidth, 0xFF6666);
            }
        }
    }
}
