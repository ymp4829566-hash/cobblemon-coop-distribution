package de.johni0702.minecraft.bobby.mixin;

import net.minecraft.world.level.biome.BiomeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BiomeManager.class)
public interface BiomeAccessAccessor {
    @Accessor
    long getBiomeZoomSeed();
}
