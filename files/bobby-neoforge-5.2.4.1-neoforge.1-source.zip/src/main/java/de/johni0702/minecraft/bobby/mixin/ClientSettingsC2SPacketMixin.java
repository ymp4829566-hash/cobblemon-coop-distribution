package de.johni0702.minecraft.bobby.mixin;

import net.minecraft.server.level.ClientInformation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(ClientInformation.class)
public abstract class ClientSettingsC2SPacketMixin {
    @ModifyArg(method = "write", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/FriendlyByteBuf;writeByte(I)Lnet/minecraft/network/FriendlyByteBuf;", ordinal = 0))
    private int clampMaxValue(int viewDistance) {
        // Cached client rendering up to 64 must not request an increased server view distance.
        return Math.min(viewDistance, 32);
    }
}
