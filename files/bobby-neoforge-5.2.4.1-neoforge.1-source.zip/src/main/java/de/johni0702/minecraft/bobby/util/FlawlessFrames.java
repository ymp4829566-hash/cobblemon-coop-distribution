package de.johni0702.minecraft.bobby.util;

import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.common.NeoForge;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Implements the "Flawless Frames" FREX feature using which third-party mods can instruct Bobby to sacrifice
 * performance (even beyond the point where it can no longer achieve interactive frame rates) in exchange for
 * a noticeable boost to quality.
 *
 * In Bobby's case, this means blocking loading all chunks are loaded from the cache.
 *
 * See https://github.com/grondag/frex/pull/9
 */
public class FlawlessFrames {
    private static final Set<Object> ACTIVE = Collections.newSetFromMap(new ConcurrentHashMap<>());

    private static final Function<String, Consumer<Boolean>> PROVIDER = name -> {
        Object token = new Object();
        return active -> {
            if (active) {
                ACTIVE.add(token);
            } else {
                ACTIVE.remove(token);
            }
        };
    };

    public static Function<String, Consumer<Boolean>> getProvider() {
        return PROVIDER;
    }

    public static void onClientInitialization() {
        NeoForge.EVENT_BUS.post(new ProviderEvent(PROVIDER));
    }

    /** NeoForge replacement for Fabric's frex_flawless_frames entrypoint. */
    public static final class ProviderEvent extends Event {
        private final Function<String, Consumer<Boolean>> provider;

        public ProviderEvent(Function<String, Consumer<Boolean>> provider) {
            this.provider = provider;
        }

        public Function<String, Consumer<Boolean>> getProvider() {
            return provider;
        }
    }

    public static boolean isActive() {
        return !ACTIVE.isEmpty();
    }
}
