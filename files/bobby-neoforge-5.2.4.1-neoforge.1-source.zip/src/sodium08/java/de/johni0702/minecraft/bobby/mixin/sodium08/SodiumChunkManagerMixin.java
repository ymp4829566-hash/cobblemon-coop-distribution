package de.johni0702.minecraft.bobby.mixin.sodium08;

import de.johni0702.minecraft.bobby.ext.ClientChunkManagerExt;
import net.caffeinemc.mods.sodium.client.render.chunk.map.ChunkStatus;
import net.caffeinemc.mods.sodium.client.render.chunk.map.ChunkTrackerHolder;
import net.minecraft.client.multiplayer.ClientChunkCache;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.SectionPos;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/** Makes cached chunks visible to Sodium's block-and-light readiness tracker. */
@Mixin(value = ClientChunkCache.class, priority = 1010)
public abstract class SodiumChunkManagerMixin implements ClientChunkManagerExt {
    @Shadow @Final
    ClientLevel level;

    @Override
    public void bobby_onFakeChunkAdded(int x, int z) {
        // A fake chunk has both its block data and saved light data installed.
        ChunkTrackerHolder.get(level).onChunkStatusAdded(x, z, ChunkStatus.FLAG_ALL);
    }

    @Override
    public void bobby_onFakeChunkRemoved(int x, int z, boolean willBeReplaced) {
        // Preserve readiness while real chunk data replaces cached data, until
        // vanilla's delayed light update has installed the real light arrays.
        boolean stillHasLight = willBeReplaced
                || level.getChunkSource().getLightEngine().lightOnInSection(SectionPos.of(x, 0, z));
        ChunkTrackerHolder.get(level).onChunkStatusRemoved(x, z,
                stillHasLight ? ChunkStatus.FLAG_HAS_BLOCK_DATA : ChunkStatus.FLAG_ALL);
    }
}
