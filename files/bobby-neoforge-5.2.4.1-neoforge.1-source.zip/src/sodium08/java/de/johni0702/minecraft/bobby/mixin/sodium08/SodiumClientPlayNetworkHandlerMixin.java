package de.johni0702.minecraft.bobby.mixin.sodium08;

import de.johni0702.minecraft.bobby.FakeChunk;
import de.johni0702.minecraft.bobby.ext.ClientChunkManagerExt;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundForgetLevelChunkPacket;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = ClientPacketListener.class, priority = 1100)
public abstract class SodiumClientPlayNetworkHandlerMixin {
    @Shadow
    private ClientLevel level;

    @Inject(method = "handleForgetLevelChunk", at = @At("RETURN"))
    private void bobby_keepCachedChunkRendered(ClientboundForgetLevelChunkPacket packet, CallbackInfo ci) {
        int x = packet.pos().x;
        int z = packet.pos().z;
        LevelChunk chunk = level.getChunk(x, z);
        // Sodium 0.8 removes FLAG_ALL at the end of this packet handler. Bobby
        // inserts the cached replacement in ClientChunkCache.drop beforehand.
        // Re-add the flags after Sodium so the replacement remains rendered.
        if (chunk instanceof FakeChunk) {
            ((ClientChunkManagerExt) level.getChunkSource()).bobby_onFakeChunkAdded(x, z);
        }
    }
}
