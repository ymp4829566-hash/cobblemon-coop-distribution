package de.johni0702.minecraft.bobby.mixin.sodium08;

import de.johni0702.minecraft.bobby.Bobby;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Slice;

/** Sodium 0.8 replaced SodiumGameOptionPages with the configuration builder API. */
@Mixin(targets = "net.caffeinemc.mods.sodium.client.gui.SodiumConfigBuilder", remap = false)
public abstract class SodiumConfigBuilderMixin {
    @ModifyArg(
            method = "buildGeneralPage",
            slice = @Slice(
                    from = @At(value = "CONSTANT", args = "stringValue=sodium:general.render_distance"),
                    to = @At(value = "CONSTANT", args = "stringValue=sodium:general.simulation_distance")
            ),
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/caffeinemc/mods/sodium/api/config/structure/IntegerOptionBuilder;setRange(III)Lnet/caffeinemc/mods/sodium/api/config/structure/IntegerOptionBuilder;",
                    ordinal = 0
            ),
            index = 1,
            require = 1
    )
    private int bobby_maxCachedRenderDistance(int vanillaMaximum) {
        // Only render distance is extended. Simulation distance and server
        // view distance are deliberately not increased by this client mod.
        return Math.max(3, Math.min(64, Bobby.getInstance().getConfig().getMaxRenderDistance()));
    }
}
