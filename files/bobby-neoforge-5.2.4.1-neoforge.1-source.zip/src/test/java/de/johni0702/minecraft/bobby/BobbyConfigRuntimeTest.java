package de.johni0702.minecraft.bobby;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.spongepowered.configurate.CommentedConfigurationNode;
import org.spongepowered.configurate.hocon.HoconConfigurationLoader;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Real Configurate/HOCON loader and real port configuration class; no Minecraft GUI initialization. */
class BobbyConfigRuntimeTest {
    @TempDir Path directory;

    @Test void defaultMaximumIs64ButIntegratedServerOverrideRemainsOff() throws Exception {
        var loader = HoconConfigurationLoader.builder().path(directory.resolve("bobby.conf")).build();
        BobbyConfig config = loader.load().get(BobbyConfig.class);
        assertNotNull(config);
        assertEquals(64, config.getMaxRenderDistance());
        assertEquals(0, config.getViewDistanceOverwrite());
        assertEquals(-1, config.getDeleteUnusedRegionsAfterDays());
        assertTrue(config.isNoBlockEntities());
        assertTrue(config.isEnabled());
    }

    @Test void maximumGetterClampsAllConstructorInputsTo3Through64() {
        for (int raw : new int[]{Integer.MIN_VALUE, -1, 0, 1, 2, 3, 16, 32, 48, 63, 64, 65, 4096, Integer.MAX_VALUE}) {
            BobbyConfig config = new BobbyConfig(true, false, true, false, 60, -1, raw, 0);
            assertEquals(Math.max(3, Math.min(64, raw)), config.getMaxRenderDistance());
            assertEquals(0, config.getViewDistanceOverwrite());
        }
    }

    @Test void hoconRoundtripPreservesAllEightOptionsAndExisting32Choice() throws Exception {
        Path path = directory.resolve("bobby.conf");
        var loader = HoconConfigurationLoader.builder().path(path).build();
        for (int raw : new int[]{2, 3, 32, 48, 64, 65}) {
            BobbyConfig original = new BobbyConfig(false, true, false, true, 17, -1, raw, 0);
            CommentedConfigurationNode node = loader.load();
            node.set(BobbyConfig.class, original);
            loader.save(node);
            assertTrue(Files.size(path) > 0);
            BobbyConfig restored = loader.load().get(BobbyConfig.class);
            assertNotNull(restored);
            assertFalse(restored.isEnabled());
            assertTrue(restored.isDynamicMultiWorld());
            assertFalse(restored.isNoBlockEntities());
            assertTrue(restored.isTaintFakeChunks());
            assertEquals(17, restored.getUnloadDelaySecs());
            assertEquals(-1, restored.getDeleteUnusedRegionsAfterDays());
            assertEquals(Math.max(3, Math.min(64, raw)), restored.getMaxRenderDistance());
            assertEquals(0, restored.getViewDistanceOverwrite());
        }
    }
}
