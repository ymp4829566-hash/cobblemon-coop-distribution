package de.johni0702.minecraft.bobby;

import de.johni0702.minecraft.bobby.util.FlawlessFrames;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Headless tests only: no Minecraft game instance, Screen.init, or GUI process is started. */
class BobbyPlatformTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void flawlessFramesProviderIsStableAndAvailableWithoutFabric() {
        assertSame(FlawlessFrames.getProvider(), FlawlessFrames.getProvider());
    }

    @Test
    void flawlessFramesIndependentClientsCannotCancelEachOther() {
        Function<String, Consumer<Boolean>> provider = FlawlessFrames.getProvider();
        Consumer<Boolean> first = provider.apply("same-client-name");
        Consumer<Boolean> second = provider.apply("same-client-name");
        try {
            assertFalse(FlawlessFrames.isActive());
            first.accept(true);
            first.accept(true);
            second.accept(true);
            assertTrue(FlawlessFrames.isActive());
            first.accept(false);
            assertTrue(FlawlessFrames.isActive());
            second.accept(false);
            assertFalse(FlawlessFrames.isActive());
        } finally {
            first.accept(false);
            second.accept(false);
        }
    }

    @Test
    void flawlessFramesNeoForgeEventExposesTheSameProvider() {
        Function<String, Consumer<Boolean>> provider = FlawlessFrames.getProvider();
        assertSame(provider, new FlawlessFrames.ProviderEvent(provider).getProvider());
    }

    @Test
    void cleanupRemovesEmptyCacheParentsButNeverTheCacheRootOrGameDirectory() throws Exception {
        Path cache = temporaryDirectory.resolve(".bobby");
        Path emptyLeaf = cache.resolve("server/dimension/world");
        Files.createDirectories(emptyLeaf);
        invokeCleanup(emptyLeaf.resolve("already-removed-region.mca"), cache);
        assertFalse(Files.exists(emptyLeaf));
        assertTrue(Files.isDirectory(cache));
        assertTrue(Files.isDirectory(temporaryDirectory));
    }

    @Test
    void cleanupDoesNotRemoveDirectoriesOutsideItsConfiguredCacheRoot() throws Exception {
        Path cache = Files.createDirectory(temporaryDirectory.resolve(".bobby"));
        Path external = Files.createDirectory(temporaryDirectory.resolve("outside"));
        invokeCleanup(external.resolve("already-removed-region.mca"), cache);
        assertTrue(Files.isDirectory(external));
        assertTrue(Files.isDirectory(cache));
    }

    private static void invokeCleanup(Path removedFile, Path cacheRoot) throws Exception {
        Method cleanup = Bobby.class.getDeclaredMethod("deleteParentsIfEmpty", Path.class, Path.class);
        cleanup.setAccessible(true);
        cleanup.invoke(null, removedFile, cacheRoot);
    }
}
