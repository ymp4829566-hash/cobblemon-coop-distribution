package de.johni0702.minecraft.bobby;

import de.johni0702.minecraft.bobby.util.FileSystemUtils;
import de.johni0702.minecraft.bobby.util.RegionPos;
import net.minecraft.world.level.ChunkPos;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/** Uses the actual patched Minecraft ChunkPos, not the earlier standalone coordinate bridge. */
class CacheUtilityRuntimeTest {
    @TempDir Path directory;

    @Test void regionCoordinatesAnd32By32StorageFormatRemainUnchangedAt64RenderRadius() {
        for (int x : new int[]{-1025, -33, -32, -1, 0, 31, 32, 1025}) {
            for (int z : new int[]{-1025, -33, -32, -1, 0, 31, 32, 1025}) {
                ChunkPos chunk = new ChunkPos(x, z);
                RegionPos region = RegionPos.from(chunk);
                assertEquals(x >> 5, region.x());
                assertEquals(z >> 5, region.z());
                assertEquals(region, RegionPos.fromLong(region.toLong()));
                var contained = region.getContainedChunks().toList();
                assertEquals(1024, contained.size());
                assertEquals(1024, new HashSet<>(contained).size());
                assertTrue(contained.contains(chunk));
            }
        }
    }

    @Test void trackerLoads64AndShrinksTo32UsingActualMinecraftPackedCoordinates() {
        VisibleChunksTracker tracker = new VisibleChunksTracker();
        Set<Long> resident = new HashSet<>();
        tracker.update(-63, 77, 64, key -> fail("initial unload"), key -> assertTrue(resident.add(key)));
        assertEquals(16641, resident.size());
        assertTrue(resident.contains(ChunkPos.asLong(-127, 141)));
        tracker.update(-63, 77, 32, key -> assertTrue(resident.remove(key)), key -> fail("shrink load"));
        assertEquals(4225, resident.size());
        assertFalse(resident.contains(ChunkPos.asLong(-127, 141)));
        assertTrue(resident.contains(ChunkPos.asLong(-95, 109)));
        Set<Long> enumerated = new HashSet<>();
        tracker.forEach(enumerated::add);
        assertEquals(resident, enumerated);
    }

    @Test void maliciousDimensionAndServerComponentsStayInIsolatedCacheRoot() throws Exception {
        Path root = directory.resolve("cache").toAbsolutePath().normalize();
        Files.createDirectories(root);
        for (String value : new String[]{"..", ".", "", "../saves/level.dat", "../../outside", "C:\\outside", "/outside", "..\\..\\outside"}) {
            Path child = FileSystemUtils.resolveChild(root, value).toAbsolutePath().normalize();
            assertTrue(child.startsWith(root));
            assertNotEquals(root, child);
            Path server = FileSystemUtils.resolveSafeDirectoryName(root, value).toAbsolutePath().normalize();
            assertEquals(root, server.getParent());
        }
    }
}
