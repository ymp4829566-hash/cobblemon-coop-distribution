package de.johni0702.minecraft.bobby;

import net.minecraft.SharedConstants;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.util.datafix.DataFixers;
import net.minecraft.world.level.ChunkPos;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** Actual patched Minecraft ChunkStorage / IOWorker / region file / NBT roundtrip, isolated files only. */
class FakeChunkStorageRuntimeTest {
    @TempDir Path directory;

    @BeforeAll static void versionOnly() {
        SharedConstants.tryDetectVersion();
        assertEquals(3955, SharedConstants.getCurrentVersion().getDataVersion().getVersion());
    }

    private FakeChunkStorage open(Path path, boolean writeable, int retention, List<Component> notifications) {
        return new FakeChunkStorage(path, writeable, DataFixers.getDataFixer(), () -> retention, notifications::add);
    }

    private static CompoundTag chunk(ChunkPos position, int version) {
        CompoundTag root = new CompoundTag();
        root.putInt("DataVersion", version);
        root.putInt("xPos", position.x);
        root.putInt("zPos", position.z);
        root.putInt("yPos", -4);
        root.putString("Status", "full");
        root.putBoolean("isLightOn", true);
        root.putLong("age", 1728000000L);
        ListTag sections = new ListTag();
        for (int y : new int[]{-4, 0, 19}) {
            CompoundTag section = new CompoundTag();
            section.putByte("Y", (byte) y);
            CompoundTag state = new CompoundTag();
            ListTag palette = new ListTag();
            CompoundTag stone = new CompoundTag(); stone.putString("Name", "minecraft:stone");
            palette.add(stone); state.put("palette", palette);
            section.put("block_states", state);
            CompoundTag biomes = new CompoundTag();
            ListTag biomePalette = new ListTag(); biomePalette.add(StringTag.valueOf("minecraft:plains"));
            biomes.put("palette", biomePalette); section.put("biomes", biomes);
            byte[] blockLight = new byte[2048], skyLight = new byte[2048];
            Arrays.fill(blockLight, (byte) (y + 17)); Arrays.fill(skyLight, (byte) 0xff);
            section.putByteArray("BlockLight", blockLight); section.putByteArray("SkyLight", skyLight);
            sections.add(section);
        }
        root.put("sections", sections);
        CompoundTag maps = new CompoundTag(); maps.putLongArray("WORLD_SURFACE", new long[]{0, Long.MIN_VALUE, Long.MAX_VALUE, -1});
        root.put("Heightmaps", maps);
        ListTag blockEntities = new ListTag();
        CompoundTag chest = new CompoundTag(); chest.putString("id", "minecraft:chest");
        chest.putInt("x", position.getMinBlockX()); chest.putInt("y", 64); chest.putInt("z", position.getMinBlockZ());
        blockEntities.add(chest); root.put("block_entities", blockEntities);
        return root;
    }

    @Test void saveFlushRestartAndReadPreserveAllCacheNbtAtNegativeAnd64Boundaries() throws Exception {
        Path path = directory.resolve("cache");
        List<Component> notifications = new ArrayList<>();
        List<ChunkPos> positions = List.of(new ChunkPos(-65, -65), new ChunkPos(-64, 64), new ChunkPos(-1, -1),
            new ChunkPos(0, 0), new ChunkPos(1, 1), new ChunkPos(64, -64), new ChunkPos(65, 65));
        try (FakeChunkStorage storage = open(path, true, -1, notifications)) {
            for (ChunkPos position : positions) storage.save(position, chunk(position, 3955));
            storage.flushWorker();
            for (ChunkPos position : positions) assertEquals(chunk(position, 3955), storage.loadTag(position).join().orElseThrow());
            assertTrue(storage.loadTag(new ChunkPos(128, -128)).join().isEmpty());
        }
        assertTrue(Files.exists(path.resolve("last_access")));
        assertTrue(Files.size(path.resolve("last_access")) > 0);
        assertTrue(Files.size(path.resolve("r.-2.2.mca")) >= 8192);
        assertTrue(Files.size(path.resolve("r.2.-2.mca")) >= 8192);
        try (FakeChunkStorage restarted = open(path, true, -1, notifications)) {
            for (ChunkPos position : positions) assertEquals(chunk(position, 3955), restarted.loadTag(position).join().orElseThrow());
            assertTrue(restarted.loadTag(new ChunkPos(127, -127)).join().isEmpty());
        }
        assertTrue(notifications.isEmpty());
    }

    @Test void outdatedAndFutureDataVersionAreFilteredWithOneNotificationOnlyAndNoRewrite() throws Exception {
        Path path = directory.resolve("versioned-cache");
        List<Component> notifications = new ArrayList<>();
        ChunkPos old = new ChunkPos(-64, 64), future = new ChunkPos(64, -64);
        try (FakeChunkStorage storage = open(path, true, -1, notifications)) {
            storage.save(old, chunk(old, 3954)); storage.save(future, chunk(future, 3956)); storage.flushWorker();
            assertTrue(storage.loadTag(old).join().isEmpty());
            assertTrue(storage.loadTag(future).join().isEmpty());
            assertTrue(storage.loadTag(old).join().isEmpty());
            assertEquals(1, notifications.size());
            assertEquals("bobby.upgrade.required", ((TranslatableContents) notifications.getFirst().getContents()).getKey());
            assertEquals(3954, storage.read(old).join().orElseThrow().getInt("DataVersion"));
            assertEquals(3956, storage.read(future).join().orElseThrow().getInt("DataVersion"));
        }
    }

    @Test void zeroRetentionDeletesUsedRegionButMinusOneKeepsItAcrossClose() throws Exception {
        ChunkPos position = new ChunkPos(-64, 64);
        Path preserved = directory.resolve("preserved"), expired = directory.resolve("expired");
        try (FakeChunkStorage storage = open(preserved, true, -1, new ArrayList<>())) {
            storage.save(position, chunk(position, 3955)); storage.flushWorker();
        }
        assertTrue(Files.exists(preserved.resolve("r.-2.2.mca")));
        try (FakeChunkStorage storage = open(expired, true, 0, new ArrayList<>())) {
            storage.save(position, chunk(position, 3955)); storage.flushWorker();
        }
        assertFalse(Files.exists(expired.resolve("r.-2.2.mca")));
        assertTrue(Files.exists(preserved.resolve("r.-2.2.mca")));
    }

    @Test void fallbackLoadDoesNotChangeExistingDataOrCreateLastAccess() throws Exception {
        Path path = directory.resolve("fallback");
        ChunkPos position = new ChunkPos(64, -64);
        try (FakeChunkStorage writable = open(path, true, -1, new ArrayList<>())) {
            writable.save(position, chunk(position, 3955)); writable.flushWorker();
        }
        byte[] regionBefore = Files.readAllBytes(path.resolve("r.2.-2.mca"));
        byte[] accessBefore = Files.readAllBytes(path.resolve("last_access"));
        List<Component> notifications = new ArrayList<>();
        try (FakeChunkStorage fallback = open(path, false, 0, notifications)) {
            assertEquals(chunk(position, 3955), fallback.loadTag(position).join().orElseThrow());
        }
        assertArrayEquals(regionBefore, Files.readAllBytes(path.resolve("r.2.-2.mca")));
        assertArrayEquals(accessBefore, Files.readAllBytes(path.resolve("last_access")));
        assertTrue(notifications.isEmpty());
    }
}
