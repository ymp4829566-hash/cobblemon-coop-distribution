Small Neighbor Pet Shop - QA
Build: qa-20261109-063159

PetShopPrototype.exe를 실행하세요. 같은 폴더의 Data, DLL, MonoBleedingEdge도 필요합니다.
itch 앱으로 설치한 테스트 버전은 같은 Windows 채널의 업데이트를 받을 수 있습니다.
브라우저에서 직접 받은 파일은 자동 업데이트되지 않습니다.

문제 제보: 이 빌드 번호 / 재현 순서 / 기대한 동작 / 실제 동작 / 스크린샷.
게임의 전체 조작은 Esc의 안내 화면에서 확인하세요.
