작은 이웃 펫샵 3인칭 탑뷰 QA
버전 0.27.0 · 빌드 qa-20261114-210343

이 폴더의 PetShopPrototype.exe로 직접 실행할 수 있습니다.
자동 업데이트를 받으려면 별도 3인칭 QA 실행기를 사용하세요.
3인칭 QA 세이브는 1인칭 QA와 일반 로컬 세이브에서 분리됩니다.
저장 위치 %USERPROFILE%\AppData\LocalLow\SmallNeighborPrototype\Small Neighbor Pet Shop Top View\QA

새 게임은 보유금 $2,000 / 레벨 20으로 시작합니다.
F2 테스트 도구에서 돈과 레벨을 조절합니다. 기존 진행을 초기화하지 않습니다.
F1 기초 튜토리얼 / ESC 일시정지 및 설정.
WASD 이동, Shift 달리기, Space 점프, Ctrl 앉기.
V 태블릿, T 꾸미기, B 가구 배치, E 근처 사육장·가구·상자 상호작용.
Q 상자 내려놓기, R 배치 회전, F5 저장, F9 불러오기 확인.

새 동물 12종과 금붕어 5색을 포함합니다.
